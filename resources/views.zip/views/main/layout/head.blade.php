<head>
    <!-- Required Meta Tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap RTL CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/bootstrap.rtl.min.css') }}">
    <!-- Animate Min CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/animate.min.css') }}">
    <!-- Flaticon CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/fonts/flaticon.css') }}">
    <!-- Boxicons CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/boxicons.min.css') }}">
    <!-- Owl Carousel Min CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/owl.carousel.min.css') }}">
    <link rel="stylesheet" href="{{ asset('mainasset/css/owl.theme.default.min.css') }}">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/magnific-popup.css') }}">
    <!-- Nice Select CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/nice-select.min.css') }}">
    <!-- Meanmenu CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/meanmenu.css') }}">
    <!-- Style CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/style.css') }}">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/responsive.css') }}">
    <!-- Theme Dark CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/theme-dark.css') }}">
    <!-- RTL CSS -->
    <link rel="stylesheet" href="{{ asset('mainasset/css/rtl.css') }}">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="{{ asset('mainasset/images/favicon.png') }}">

    <title>عدد صناعية</title>
</head>
