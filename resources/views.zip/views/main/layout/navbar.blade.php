<div class="navbar-area">
    <!-- Menu For Mobile Device -->
    <div class="mobile-nav">
        <a href="index.html" class="logo">
            <img src="{{ asset('mainasset/images/logos/logo-1.png') }}" class="logo-one" alt="Logo">
            <img src="{{ asset('mainasset/images/logos/logo-2.png') }}" class="logo-two" alt="Logo">
        </a>
    </div>

    <!-- Menu For Desktop Device -->
    <div class="main-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light ">
                <a class="navbar-brand" href="index.html">
                    <img src="{{ asset('mainasset/images/logos/logo-1.png') }}" class="logo-one" alt="Logo">
                    <img src="{{ asset('mainasset/images/logos/logo-2.png') }}" class="logo-two" alt="Logo">
                </a>

                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav m-auto">
                        <li class="nav-item">
                            <a href="index.html" class="nav-link active">
                                الرئيسية
                            </a>
                        </li>
                        @forelse ($departments as $department )
                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                {{ $department->name }} <i class='bx bx-caret-down'></i>
                            </a>
                            <ul class="dropdown-menu">
                                @foreach ($department->categories as $category)
                                <li class="nav-item">
                                    <a href="index.html" class="nav-link active">
                                        {{ $category->name }}
                                    </a>
                                </li>
                                @endforeach


                            </ul>
                        </li>
                        @empty

                        @endforelse


                    </ul>

                    <div class="nav-side d-display">
                        <div class="nav-side-item">
                            <div class="search-box">
                                <i class='bx bx-search'></i>
                            </div>
                        </div>

                        <div class="nav-side-item">
                            <div class="get-btn">
                                <a href="contact.html" class="default-btn btn-bg-two border-radius-50">تسجيل الدخول / دخول<i class='bx bx-chevron-right'></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    </div>

    <div class="side-nav-responsive">
        <div class="container-max">
            <div class="dot-menu">
                <div class="circle-inner">
                    <div class="in-circle circle-one"></div>
                    <div class="in-circle circle-two"></div>
                    <div class="in-circle circle-three"></div>
                </div>
            </div>

            <div class="container">
                <div class="side-nav-inner">
                    <div class="side-nav justify-content-center align-items-center">
                        <div class="side-nav-item nav-side">
                            <div class="search-box">
                                <i class='bx bx-search'></i>
                            </div>
                            <div class="get-btn">
                                <a href="contact.html" class="default-btn btn-bg-two border-radius-50">Get A Quote <i class='bx bx-chevron-right'></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
