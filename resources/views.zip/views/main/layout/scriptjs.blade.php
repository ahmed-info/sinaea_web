        <!-- Color Switch Button -->
        <div class="switch-box">
            <label id="switch" class="switch">
                <input type="checkbox" onchange="toggleTheme()" id="slider">
                <span class="slider round"></span>
            </label>
        </div>
        <!-- Color Switch Button End -->


        <!-- Jquery Min JS -->
        <script src="{{ asset('mainasset/js/jquery.min.js') }}"></script>
        <!-- Bootstrap Bundle Min JS -->
        <script src="{{ asset('mainasset/js/bootstrap.bundle.min.js') }}"></script>
        <!-- Owl Carousel Min JS -->
        <script src="{{ asset('mainasset/js/owl.carousel.min.js') }}"></script>
        <!-- Magnific Popup Min JS -->
        <script src="{{ asset('mainasset/js/jquery.magnific-popup.min.js') }}"></script>
        <!-- Nice Select Min JS -->
        <script src="{{ asset('mainasset/js/jquery.nice-select.min.js') }}"></script>
        <!-- Wow Min JS -->
        <script src="{{ asset('mainasset/js/wow.min.js') }}"></script>
        <!-- Meanmenu JS -->
        <script src="{{ asset('mainasset/js/meanmenu.js') }}"></script>
        <!-- Ajaxchimp Min JS -->
        <script src="{{ asset('mainasset/js/jquery.ajaxchimp.min.js') }}"></script>
        <!-- Form Validator Min JS -->
        <script src="{{ asset('mainasset/js/form-validator.min.js') }}"></script>
        <!-- Contact Form JS -->
        <script src="{{ asset('mainasset/js/contact-form-script.js') }}"></script>
        <!-- Custom JS -->
        <script src="{{ asset('mainasset/js/custom.js') }}"></script>
